# Simply - responsive resume template
# copyright 2013 prettyspoon.com
# author: Uvis Grinfelds
#



Thanks, for buying this template

HTML Document is well commented. All you need to do is to navigate through the document and replace the dummy content. If you have any doubts contact me.

Simply is clean, minimal and professional looking resume template. This theme is hand crafted, with typography and simplicity in mind. It is so simple, that it will take only 5 minutes to set it up, and if you have any problems, you are more than welcome to contact me.

Enjoy it!

Features

-Fully Responsive Design, try for your self, re-size your browser.
-More than 240 awesome icons. Check them out: http://fortawesome.github.com/Font-Awesome/
-Fully ready to be printed
-Professional looking.
-Easy to customize, easily make it original,

Thank you: 
Bootstrap: http://twitter.github.com/bootstrap/
Font-awesome http://fortawesome.github.com/Font-Awesome/
Image: http://www.flickr.com/photos/amslerpix/7179887656/
